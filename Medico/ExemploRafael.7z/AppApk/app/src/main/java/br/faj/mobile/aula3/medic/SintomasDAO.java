package br.faj.mobile.aula3.medic;

public class SintomasDAO {

    private Sintomas sintomas;


}
